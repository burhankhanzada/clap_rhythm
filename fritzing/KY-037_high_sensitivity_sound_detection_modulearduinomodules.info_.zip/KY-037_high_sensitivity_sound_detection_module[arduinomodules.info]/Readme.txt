﻿//
// ARDUINOMODULES.INFO
// KY-037 High Sensitivity Sound Detection Module
//
// https://arduinomodules.info/ky-037-high-sensitivity-sound-detection-module/
//



File includes:
 |
 |- KY-037 High Sensitivity Sound Detection Module.fzpz		//Fritzing Custom Part
 |
 |- Readme.txt							//This file 



Changelog:
  
  Mar-2023
    - Initial release


Disclaimer:

KY-037 High Sensitivity Sound Detection Module Fritzing Part is created by arduinomodules.info and published under Creative Commons Attribution-ShareAlike 4.0 International license (https://creativecommons.org/licenses/by-sa/4.0/).
You can use it, share it and/or modify it for any purposes as long as you distribute it under the same license and provide appropriate credit.
